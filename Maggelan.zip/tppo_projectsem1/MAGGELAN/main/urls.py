from django.urls import path
from . import views
from .views import RegisterView, SightsDetailView

urlpatterns = [
    path('', views.show_mainWA, name = 'home'),
    path('requestSight', views.show_requestSight, name = 'requestSight'),
    path('AddSight', views.show_AddrequestSight, name = 'AddSight'),
    path('profile', views.show_profile, name = 'profile'),
    path('register', RegisterView.as_view(), name = 'register'),
    path('<int:pk>', SightsDetailView.as_view(), name = 'sight_detail'),
    path('PersonalAddSight', views.show_AddPersonalSight, name = 'PersonalAddSight'),
    path('PersonalMap', views.show_PersonalMap, name = 'PersonalMap'),
]