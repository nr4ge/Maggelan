var map_magID = L.map(
                "map_magID",
                {
                    center: [61.778041, 34.364169],
                    crs: L.CRS.EPSG3857,
                    zoom: 12,
                    zoomControl: true,
                    preferCanvas: false,
                }
            );
            var tile_layer_8324b3defd3f43ff95a36413300dbbbf = L.tileLayer(
                "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
                {"attribution": "Data by \u0026copy; \u003ca target=\"_blank\" href=\"http://openstreetmap.org\"\u003eOpenStreetMap\u003c/a\u003e, under \u003ca target=\"_blank\" href=\"http://www.openstreetmap.org/copyright\"\u003eODbL\u003c/a\u003e.", "detectRetina": false, "maxNativeZoom": 18, "maxZoom": 18, "minZoom": 0, "noWrap": false, "opacity": 1, "subdomains": "abc", "tms": false}
            );
            tile_layer_8324b3defd3f43ff95a36413300dbbbf.addTo(map_magID);

            var marker_56e13e881d3feaa1b93b3354569accaa = L.marker(
                [51.5074, 0.1278],
                {}
            ).addTo(map_magID);
        var popup_fb0681efa0c2c88677cc93ab57c22812 = L.popup({"maxWidth": "100%"});
        var html_89b5660d253eb76520560288452eb365 = $(`<div id="html_89b5660d253eb76520560288452eb365" style="width: 100.0%; height: 100.0%;">London</div>`)[0];
                popup_fb0681efa0c2c88677cc93ab57c22812.setContent(html_89b5660d253eb76520560288452eb365);
        marker_56e13e881d3feaa1b93b3354569accaa.bindPopup(popup_fb0681efa0c2c88677cc93ab57c22812);

function success({ coords }) {
  // получаем широту и долготу
  const { latitude, longitude } = coords
  const position = [latitude, longitude]
  L.marker(position).addTo(map_magID).bindPopup('You are here').openPopup()
}

function error({ message }) {
  console.log(message) // при отказе в доступе получаем PositionError: User denied Geolocation
}
        document.getElementById('my_position').onclick = () => {
  navigator.geolocation.getCurrentPosition(success, error, {
    enableHighAccuracy: true
  })
}
