from django.db import models
from django.utils import timezone
# Create your models here.
class Sight(models.Model):
    Title = models.CharField('Название', max_length=128)
    XCoordinate = models.FloatField('X:')
    YCoordinate = models.FloatField('Y:')
    Info = models.TextField('Описание', max_length=2048)
    Picture = models.ImageField(upload_to='main/SightPictures/', blank=True)

    def __str__(self):
        return self.Title

class RequestSight(models.Model):
    Title = models.CharField('Название', max_length=128)
    XCoordinate = models.FloatField('X:')
    YCoordinate = models.FloatField('Y:')
    Info = models.TextField('Описание', max_length=2048)
    Picture = models.ImageField(upload_to='main/RequestSightPictures/')

    def __str__(self):
        return self.Title

class UsersReviews(models.Model):
    UserID = models.CharField(verbose_name='UID:', max_length=256)
    SightID = models.IntegerField(verbose_name='SID:')
    Review = models.TextField(verbose_name='Review:', max_length=4096)
    Rating = models.IntegerField(verbose_name="Rating:")
    create_date = models.DateField(default=timezone.now)
    status = models.BooleanField(verbose_name="видимость",default=False)

    def __str__(self):
        return self.UserID

class PersonalSight(models.Model):
    UserID = models.CharField(verbose_name='UID:', max_length=256)
    Title = models.CharField('Название', max_length=128)
    XCoordinate = models.FloatField('X:')
    YCoordinate = models.FloatField('Y:')
    Info = models.TextField('Описание', max_length=2048)
    Picture = models.ImageField(upload_to='main/PersonalSightPictures/')

    def __str__(self):
        return self.Title