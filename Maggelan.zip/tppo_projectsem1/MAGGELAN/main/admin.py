from django.contrib import admin
from .models import Sight, RequestSight, UsersReviews, PersonalSight

# Register your models here.

admin.site.register(Sight)
admin.site.register(RequestSight)
admin.site.register(UsersReviews)
admin.site.register(PersonalSight)