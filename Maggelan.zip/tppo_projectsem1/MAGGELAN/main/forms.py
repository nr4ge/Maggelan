from django.contrib.auth.forms import UserCreationForm

from .models import Sight, UsersReviews, PersonalSight
from .models import RequestSight
from django.forms import ModelForm, TextInput, Textarea, NumberInput, FileField

class SightForm(ModelForm):
    class Meta:
        model = Sight
        fields = ["Title", "XCoordinate", "YCoordinate", "Info", "Picture"]
class RequestSightForm(ModelForm):
    class Meta:
        model = RequestSight
        fields = ["Title", "XCoordinate", "YCoordinate", "Info", "Picture"]

class RegisterForm(UserCreationForm):
    pass

class ReviewForm(ModelForm):
    class Meta:
        model = UsersReviews
        fields = ["UserID", "SightID", "Review", "Rating"]

class PersonalSightForm(ModelForm):
    class Meta:
        model = PersonalSight
        fields = ["UserID","Title", "XCoordinate", "YCoordinate", "Info", "Picture"]