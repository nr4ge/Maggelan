from django.contrib.auth.decorators import login_required
from django.http import HttpResponseRedirect
from django.shortcuts import render, redirect
from django.urls import reverse_lazy
from django.views.generic import CreateView, FormView, DetailView
from django.views.generic.edit import FormMixin

from .models import RequestSight, Sight, UsersReviews, PersonalSight
from .forms import RequestSightForm, SightForm, RegisterForm, ReviewForm, PersonalSightForm
import folium
import shutil
# Create your views here.
def show_mainWA(request):
    search_query = request.GET.get('search','')
    if(search_query):
        Sights = Sight.objects.filter(Title__icontains=search_query)
    else:
        Sights = Sight.objects.all()
    return render(request, 'main/mainWA.html', {"Sights":Sights})

def show_requestSight(request):
    error = ''
    if request.method == 'POST':
        form = RequestSightForm(request.POST, request.FILES)
        if form.is_valid():
            text_data = form.cleaned_data['Title']
            X_data = form.cleaned_data['XCoordinate']
            Y_data = form.cleaned_data['YCoordinate']
            Info_data = form.cleaned_data['Info']
            file_data = form.cleaned_data['Picture']
            RequestSightModel = RequestSight(Title=text_data, XCoordinate=X_data, YCoordinate=Y_data,Info=Info_data,Picture=file_data)
            RequestSightModel.save()
            return redirect('home')
        else:
            print(form.errors)
            error = 'Неверные данные'
    form = RequestSightForm()
    context = {
        'form': form,
        'error':error
    }
    return render(request, 'main/requestSight.html', context)

def show_AddrequestSight(request):
    AllRequestSights = RequestSight.objects.all().values_list()
    AllSights = Sight.objects.all().values_list()
    isFalse = []
    for s in AllSights:
        for rs in AllRequestSights:
            if(s[2] == rs[2] and s[3] == rs[3]):
                isFalse.append(rs[0])
    TrueRequestionSights = RequestSight.objects.all()
    TrueRequestionSights = TrueRequestionSights.exclude(id__in=[o for o in isFalse])
    error = ''
    if request.method == 'POST':
        form = SightForm(request.POST, request.FILES)
        if form.is_valid():
            text_data = form.cleaned_data['Title']
            X_data = form.cleaned_data['XCoordinate']
            Y_data = form.cleaned_data['YCoordinate']
            Info_data = form.cleaned_data['Info']
            for RS in AllRequestSights:
                print(RS)
                if(RS[2] == X_data and RS[3] == Y_data):
                    file_data = RS[5]
            print(file_data)
            AddSightModel = Sight(Title=text_data, XCoordinate=X_data, YCoordinate=Y_data, Info=Info_data,
                                             Picture=file_data)
            AddSightModel.save()
            return redirect('AddSight')
        else:
            print(form.errors)
            error = 'Неверные данные'
    form = SightForm()
    context = {
        'form': form,
        'error': error,
        "AllRequestSights": TrueRequestionSights,
        "AllSights":AllSights
    }
    return render(request, "main/AddSight.html", context)

@login_required
def show_profile(request):
    return render(request, "main/profile.html")

class RegisterView(FormView):
    form_class = RegisterForm
    template_name = 'main/register.html'
    success_url = reverse_lazy("profile")
    def form_valid(self, form):
        form.save()
        return super().form_valid(form)


class SightsDetailView(FormMixin, DetailView):
    model = Sight
    template_name = 'main/details_sight_view.html'
    context_object_name = "sight"
    form_class = ReviewForm

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['Reviews'] = UsersReviews.objects.all()
        return context

    def post(self, request, *args, **kwargs):
        self.object = self.get_object()
        form = self.get_form()
        if form.is_valid():
            user_data = form.cleaned_data['UserID']
            sight_data = form.cleaned_data['SightID']
            review_data = form.cleaned_data['Review']
            rating_data = form.cleaned_data['Rating']
            ReviewModel = UsersReviews(UserID=user_data, SightID=sight_data, Review=review_data, Rating=rating_data)
            print(ReviewModel)
            ReviewModel.save()
            return redirect(request.META.get('HTTP_REFERER'))
        else:
            return self.form_invalid(form)

def show_AddPersonalSight(request):
    error = ''
    if request.method == 'POST':
        form = PersonalSightForm(request.POST, request.FILES)
        if form.is_valid():
            userid_data = form.cleaned_data['UserID']
            text_data = form.cleaned_data['Title']
            X_data = form.cleaned_data['XCoordinate']
            Y_data = form.cleaned_data['YCoordinate']
            Info_data = form.cleaned_data['Info']
            file_data = form.cleaned_data['Picture']
            PersonalSightModel = PersonalSight(UserID=userid_data,Title=text_data, XCoordinate=X_data, YCoordinate=Y_data,Info=Info_data,Picture=file_data)
            PersonalSightModel.save()
            return redirect('home')
        else:
            print(form.errors)
            error = 'Неверные данные'
    form = PersonalSightForm()
    context = {
        'form': form,
        'error':error
    }
    return render(request, 'main/PersonalAddSight.html', context)

def show_PersonalMap(request):
    search_query = request.GET.get('search','')
    if(search_query):
        Sights = PersonalSight.objects.filter(Title__icontains=search_query, UserID=request.user)
    else:
        Sights = PersonalSight.objects.filter(UserID=request.user)
    return render(request, 'main/mainWA.html', {"Sights":Sights})